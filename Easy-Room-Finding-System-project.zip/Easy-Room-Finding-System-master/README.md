# Easy Room Finding System
<br>
Group Name: Extreme
<br>
Project Name: ERFS(Easy Room Finding System)
<br>
Group Members: 
<br>
-Dharma Raj Thanait
<br>
-Ajal Tandukar
<br>
-Sahani Shakya
<br>

Project Description:
This is group project.
It is Web application which focuses on uploading assets(house, land, flats, rooms) to sell or rent and to book assets to buy or rent. This app is made Using Python and django framework.
